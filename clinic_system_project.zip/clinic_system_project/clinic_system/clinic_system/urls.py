from django.contrib import admin
from django.urls import path
from django.http import HttpResponse

def home(request):
    return HttpResponse("""
        <h1>🏥 Welcome to HealthPlus Clinic</h1>
        <p>Your health is our priority. We offer 24/7 healthcare services.</p>
    """)

def doctors(request):
    return HttpResponse("""
        <h2>👨‍⚕️ Our Doctors</h2>
        <ul>
            <li>Dr. Sarah Ahmed – Cardiologist</li>
            <li>Dr. Ali Raza – Neurologist</li>
            <li>Dr. Maria Khan – Pediatrician</li>
        </ul>
    """)

def appointment(request):
    return HttpResponse("""
        <h2>📅 Book an Appointment</h2>
        <p>You can call us at (042) 123-4567 or visit our reception to book an appointment with our specialists.</p>
    """)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home),
    path('doctors/', doctors),
    path('appointment/', appointment),
]
